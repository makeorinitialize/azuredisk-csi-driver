/*
Copyright 2026 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package azuredisk

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/Azure/azure-sdk-for-go/sdk/azcore"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/compute/armcompute/v7"
	"github.com/container-storage-interface/spec/lib/go/csi"
	"github.com/stretchr/testify/require"
	"go.uber.org/mock/gomock"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"
	core "k8s.io/api/core/v1"
	storage "k8s.io/api/storage/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/rest"
	ktesting "k8s.io/client-go/testing"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/azuredisk-csi-driver/pkg/devicelease"
	pb "sigs.k8s.io/azuredisk-csi-driver/pkg/devicelease/api/v1"
	"sigs.k8s.io/cloud-provider-azure/pkg/azclient/diskclient/mock_diskclient"
	"sigs.k8s.io/cloud-provider-azure/pkg/azclient/mock_azclient"
	mockvm "sigs.k8s.io/cloud-provider-azure/pkg/azclient/virtualmachineclient/mock_virtualmachineclient"
)

type onlineTestClaim struct {
	Name     string                    `json:"name"`
	UID      types.UID                 `json:"uid,omitempty"`
	ClassUID types.UID                 `json:"classUID"`
	Binding  storage.VolumeBindingMode `json:"binding"`
	PVName   string                    `json:"pvName,omitempty"`
	PVUID    types.UID                 `json:"pvUID,omitempty"`
	Handle   string                    `json:"handle,omitempty"`
}

type onlineTestJournal struct {
	Config devicelease.BackingConfig `json:"config"`
	Owner  string                    `json:"owner"`
	Origin onlineTestClaim           `json:"origin"`
	Cache  onlineTestClaim           `json:"cache"`
}

func onlineAddress(t *testing.T) string {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	address := l.Addr().String()
	require.NoError(t, l.Close())
	return address
}

func onlineCertificate(t *testing.T, serial int64, parent *tls.Certificate, server bool) tls.Certificate {
	t.Helper()
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	require.NoError(t, err)
	template := &x509.Certificate{SerialNumber: big.NewInt(serial), Subject: pkix.Name{CommonName: "online-test"},
		NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature,
		BasicConstraintsValid: true}
	signer := any(key)
	issuer := template
	if parent == nil {
		template.IsCA = true
		template.KeyUsage |= x509.KeyUsageCertSign
	} else {
		issuer, signer = parent.Leaf, parent.PrivateKey
		if server {
			template.DNSNames = []string{"online.provider.test"}
			template.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}
		} else {
			template.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth}
		}
	}
	der, err := x509.CreateCertificate(rand.Reader, template, issuer, &key.PublicKey, signer)
	require.NoError(t, err)
	leaf, err := x509.ParseCertificate(der)
	require.NoError(t, err)
	return tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key, Leaf: leaf}
}

type onlineDriverFixture struct {
	d                            *Driver
	kube                         *fake.Clientset
	cfg                          onlineDomainConfig
	journal                      onlineTestJournal
	composite                    map[string]any
	sourceMu                     sync.Mutex
	id, diskID, vmID             string
	controllerCert, nodeCert, ca tls.Certificate
}

func newOnlineDriverFixture(t *testing.T, drivers ...string) *onlineDriverFixture {
	t.Helper()
	ctrl := gomock.NewController(t)
	driver, err := NewFakeDriver(ctrl)
	require.NoError(t, err)
	d := &driver.(*fakeDriver).Driver
	d.NodeID = ""
	d.onlineConfigPath = filepath.Join(t.TempDir(), "online.json")
	d.endpoint = "tcp://" + onlineAddress(t)
	diskID := fmt.Sprintf("/subscriptions/%s/resourceGroups/%s/providers/Microsoft.Compute/disks/online-origin", d.cloud.SubscriptionID, d.cloud.ResourceGroup)
	vmID := fmt.Sprintf("/subscriptions/%s/resourceGroups/%s/providers/Microsoft.Compute/virtualMachines/vm1", d.cloud.SubscriptionID, d.cloud.ResourceGroup)
	id := "dmstack-" + strings.Repeat("a", 52)
	cfg := onlineDomainConfig{Identity: devicelease.OnlineIdentity{ProviderID: "azure-canary-origin", PoolID: "bound-block-one", CompositeCRDUID: "crd-uid",
		Backing: devicelease.BackingConfig{Namespace: "backing", NamespaceUID: "ns-uid", NodeName: "vm1", NodeUID: "node-uid",
			OriginStorageClass: "azure-block", CacheStorageClass: "acs-block", OriginBytes: 1 << 30, CacheBytes: 1 << 30}},
		JournalNamespace: "ns", JournalName: "online", JournalUID: "online-uid", Endpoint: onlineAddress(t)}
	if len(drivers) != 0 {
		require.Len(t, drivers, 2)
		cfg.Identity.Backing.OriginDriver, cfg.Identity.Backing.CacheDriver = drivers[0], drivers[1]
		d.Name = cfg.Identity.Backing.EffectiveOriginDriver()
	}
	j := onlineTestJournal{Config: cfg.Identity.Backing, Owner: id + ".composite-uid"}
	for role, pin := range map[string]*onlineTestClaim{"origin": &j.Origin, "cache": &j.Cache} {
		sum := sha256.Sum256([]byte(j.Owner))
		*pin = onlineTestClaim{Name: fmt.Sprintf("dmstack-%x-%s", sum[:20], role), UID: types.UID(role + "-pvc-uid"), ClassUID: types.UID(role + "-sc-uid"), Binding: storage.VolumeBindingImmediate}
	}
	raw, err := json.Marshal(j)
	require.NoError(t, err)
	cv := map[string]any{"apiVersion": "storage.infinitydb.io/v1alpha1", "kind": "CompositeVolume",
		"metadata": map[string]any{"name": id, "uid": "composite-uid", "resourceVersion": "1", "finalizers": []any{"dmstack.csi.infinitydb.io/backing-pvcs"},
			"annotations": map[string]any{"dmstack.csi.infinitydb.io/backing-pvcs-v1": string(raw), "dmstack.csi.infinitydb.io/selected-node": "vm1"}},
		"spec": map[string]any{"capacity": int64(1 << 30), "cacheBytes": int64(1 << 30),
			"originParameters": map[string]any{"provider": cfg.Identity.ProviderID, "poolID": cfg.Identity.PoolID, "requestID": "reserve-origin"}}}
	initial, err := devicelease.InitialOnlineDomain(cfg.Identity)
	require.NoError(t, err)
	kube := fake.NewSimpleClientset(&core.ConfigMap{ObjectMeta: metav1.ObjectMeta{Name: "online", Namespace: "ns", UID: "online-uid", ResourceVersion: "1"}, Data: initial},
		&core.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "backing", UID: "ns-uid", ResourceVersion: "1", Labels: map[string]string{"dmstack.csi.infinitydb.io/backing-namespace": "v1"}}},
		&core.Node{ObjectMeta: metav1.ObjectMeta{Name: "vm1", UID: "node-uid", ResourceVersion: "1"}, Spec: core.NodeSpec{ProviderID: "azure://" + vmID}})
	kube.PrependReactor("update", "configmaps", func(a ktesting.Action) (bool, runtime.Object, error) {
		next := a.(ktesting.UpdateAction).GetObject().(*core.ConfigMap).DeepCopy()
		old, err := kube.Tracker().Get(a.GetResource(), next.Namespace, next.Name)
		if err != nil {
			return true, nil, err
		}
		prev := old.(*core.ConfigMap)
		if next.UID != prev.UID || next.ResourceVersion != prev.ResourceVersion {
			return true, nil, apierrors.NewConflict(a.GetResource().GroupResource(), next.Name, errors.New("stale RV"))
		}
		version, err := strconv.Atoi(next.ResourceVersion)
		require.NoError(t, err)
		next.ResourceVersion = strconv.Itoa(version + 1)
		require.NoError(t, kube.Tracker().Update(a.GetResource(), next, next.Namespace))
		return true, next, nil
	})
	for _, side := range []struct {
		role, class, driver string
		pin                 onlineTestClaim
	}{
		{"origin", "azure-block", cfg.Identity.Backing.EffectiveOriginDriver(), j.Origin}, {"cache", "acs-block", cfg.Identity.Backing.EffectiveCacheDriver(), j.Cache},
	} {
		require.NoError(t, kube.Tracker().Add(&storage.StorageClass{ObjectMeta: metav1.ObjectMeta{Name: side.class, UID: side.pin.ClassUID, ResourceVersion: "1"},
			Provisioner: side.driver, VolumeBindingMode: ptr.To(storage.VolumeBindingImmediate)}))
		pvc := &core.PersistentVolumeClaim{ObjectMeta: metav1.ObjectMeta{Name: side.pin.Name, Namespace: "backing", UID: side.pin.UID, ResourceVersion: "1",
			Annotations: map[string]string{"dmstack.csi.infinitydb.io/composite-handle": j.Owner, "dmstack.csi.infinitydb.io/backing-role": side.role},
			Finalizers:  []string{"dmstack.csi.infinitydb.io/backing-pvcs"}},
			Spec: core.PersistentVolumeClaimSpec{StorageClassName: &side.class, VolumeMode: ptr.To(core.PersistentVolumeBlock), AccessModes: []core.PersistentVolumeAccessMode{core.ReadWriteOnce},
				Resources: core.VolumeResourceRequirements{Requests: core.ResourceList{core.ResourceStorage: resource.MustParse("1Gi")}}},
			Status: core.PersistentVolumeClaimStatus{Phase: core.ClaimPending}}
		if side.role == "cache" {
			pvc.Annotations["localdisk.csi.acstor.io/accept-ephemeral-storage"] = "true"
		}
		require.NoError(t, kube.Tracker().Add(pvc))
	}
	d.kubeClient = kube
	f := &onlineDriverFixture{d: d, kube: kube, cfg: cfg, journal: j, composite: cv, id: id, diskID: diskID, vmID: vmID}
	source := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			t.Errorf("unexpected source write: %s %s", r.Method, r.URL.Path)
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		if r.URL.Path == "/apis/apiextensions.k8s.io/v1/customresourcedefinitions/compositevolumes.storage.infinitydb.io" {
			_ = json.NewEncoder(w).Encode(map[string]any{"apiVersion": "apiextensions.k8s.io/v1", "kind": "CustomResourceDefinition",
				"metadata": map[string]any{"name": "compositevolumes.storage.infinitydb.io", "uid": "crd-uid"},
				"spec": map[string]any{"scope": "Cluster", "group": "storage.infinitydb.io", "names": map[string]any{"plural": "compositevolumes", "kind": "CompositeVolume"},
					"versions": []any{map[string]any{"name": "v1alpha1", "served": true}}}})
			return
		}
		if r.URL.Path == "/apis/storage.infinitydb.io/v1alpha1/compositevolumes/"+id {
			f.sourceMu.Lock()
			defer f.sourceMu.Unlock()
			_ = json.NewEncoder(w).Encode(f.composite)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(source.Close)
	d.onlineRESTConfig = &rest.Config{Host: source.URL}
	f.ca = onlineCertificate(t, 1, nil, false)
	f.controllerCert = onlineCertificate(t, 2, &f.ca, false)
	f.nodeCert = onlineCertificate(t, 3, &f.ca, false)
	serverCert := onlineCertificate(t, 4, &f.ca, true)
	dir := filepath.Dir(d.onlineConfigPath)
	f.cfg.ServerCertFile, f.cfg.ServerKeyFile, f.cfg.ClientCAFile = filepath.Join(dir, "server.pem"), filepath.Join(dir, "key.pem"), filepath.Join(dir, "ca.pem")
	key, err := x509.MarshalPKCS8PrivateKey(serverCert.PrivateKey)
	require.NoError(t, err)
	require.NoError(t, os.WriteFile(f.cfg.ServerCertFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: serverCert.Certificate[0]}), 0600))
	require.NoError(t, os.WriteFile(f.cfg.ServerKeyFile, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key}), 0600))
	require.NoError(t, os.WriteFile(f.cfg.ClientCAFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: f.ca.Certificate[0]}), 0600))
	for _, entry := range []struct {
		cert tls.Certificate
		role devicelease.ReservationRole
		node string
	}{{f.controllerCert, devicelease.ReservationController, ""}, {f.nodeCert, devicelease.ReservationNode, "vm1"}} {
		digest := sha256.Sum256(entry.cert.Certificate[0])
		f.cfg.Grants = append(f.cfg.Grants, devicelease.OnlineGrant{ClientSHA256: hex.EncodeToString(digest[:]), Role: entry.role, NodeID: entry.node})
	}
	config, err := json.Marshal(f.cfg)
	require.NoError(t, err)
	require.NoError(t, os.WriteFile(d.onlineConfigPath, config, 0600))
	// Read-only also works on WSL/DrvFS mounts without POSIX mode metadata.
	require.NoError(t, os.Chmod(d.onlineConfigPath, 0444))
	t.Cleanup(func() { _ = os.Chmod(d.onlineConfigPath, 0600) })
	return f
}

func (f *onlineDriverFixture) start(t *testing.T) (csi.ControllerClient, pb.DeviceProviderClient) {
	t.Helper()
	ctx, cancel := context.WithCancel(t.Context())
	done := make(chan error, 1)
	go func() { done <- f.d.Run(ctx) }()
	t.Cleanup(func() {
		cancel()
		select {
		case err := <-done:
			require.NoError(t, err)
		case <-time.After(5 * time.Second):
			t.Error("driver did not stop")
		}
	})
	conn, err := grpc.NewClient(strings.TrimPrefix(f.d.endpoint, "tcp://"), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	ready, stop := context.WithTimeout(t.Context(), 5*time.Second)
	defer stop()
	info, err := csi.NewIdentityClient(conn).GetPluginInfo(ready, &csi.GetPluginInfoRequest{}, grpc.WaitForReady(true))
	require.NoError(t, err)
	require.Equal(t, f.d.Name, info.Name)
	return csi.NewControllerClient(conn), f.provider(t, f.controllerCert)
}

func (f *onlineDriverFixture) provider(t *testing.T, cert tls.Certificate) pb.DeviceProviderClient {
	t.Helper()
	roots := x509.NewCertPool()
	roots.AddCert(f.ca.Leaf)
	conn, err := grpc.NewClient(f.cfg.Endpoint, grpc.WithTransportCredentials(credentials.NewTLS(&tls.Config{MinVersion: tls.VersionTLS13, RootCAs: roots, ServerName: "online.provider.test", Certificates: []tls.Certificate{cert}})))
	require.NoError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	return pb.NewDeviceProviderClient(conn)
}

func (f *onlineDriverFixture) bind(t *testing.T) {
	t.Helper()
	for role, pin := range map[string]*onlineTestClaim{"origin": &f.journal.Origin, "cache": &f.journal.Cache} {
		class, driver, id := "azure-block", f.cfg.Identity.Backing.EffectiveOriginDriver(), f.diskID
		if role == "cache" {
			class, driver, id = "acs-block", f.cfg.Identity.Backing.EffectiveCacheDriver(), "vg#pv"
		}
		pin.PVName, pin.PVUID, pin.Handle = role+"-pv", types.UID(role+"-pv-uid"), id
		pvc, err := f.kube.CoreV1().PersistentVolumeClaims("backing").Get(t.Context(), pin.Name, metav1.GetOptions{})
		require.NoError(t, err)
		pvc.Spec.VolumeName = pin.PVName
		pvc.Status.Phase = core.ClaimBound
		pvc.Status.Capacity = core.ResourceList{core.ResourceStorage: resource.MustParse("1Gi")}
		_, err = f.kube.CoreV1().PersistentVolumeClaims("backing").Update(t.Context(), pvc, metav1.UpdateOptions{})
		require.NoError(t, err)
		pv := &core.PersistentVolume{ObjectMeta: metav1.ObjectMeta{Name: pin.PVName, UID: pin.PVUID, ResourceVersion: "1", Annotations: map[string]string{"pv.kubernetes.io/provisioned-by": driver}},
			Spec: core.PersistentVolumeSpec{StorageClassName: class, VolumeMode: ptr.To(core.PersistentVolumeBlock), AccessModes: []core.PersistentVolumeAccessMode{core.ReadWriteOnce},
				Capacity: core.ResourceList{core.ResourceStorage: resource.MustParse("1Gi")}, ClaimRef: &core.ObjectReference{Name: pin.Name, Namespace: "backing", UID: pin.UID},
				PersistentVolumeSource: core.PersistentVolumeSource{CSI: &core.CSIPersistentVolumeSource{Driver: driver, VolumeHandle: id}},
				NodeAffinity:           &core.VolumeNodeAffinity{Required: &core.NodeSelector{NodeSelectorTerms: []core.NodeSelectorTerm{{MatchFields: []core.NodeSelectorRequirement{{Key: "metadata.name", Operator: core.NodeSelectorOpIn, Values: []string{"vm1"}}}}}}}},
			Status: core.PersistentVolumeStatus{Phase: core.VolumeBound}}
		require.NoError(t, f.kube.Tracker().Add(pv))
	}
	data, err := json.Marshal(f.journal)
	require.NoError(t, err)
	f.sourceMu.Lock()
	defer f.sourceMu.Unlock()
	meta := f.composite["metadata"].(map[string]any)
	meta["resourceVersion"] = "2"
	meta["annotations"].(map[string]any)["dmstack.csi.infinitydb.io/backing-pvcs-v1"] = string(data)
}

func TestOnlineDriverStartupCreateReserveDelete(t *testing.T) {
	t.Run("legacy official defaults", func(t *testing.T) { runOnlineDriverCreateReserveDelete(t, "", "") })
	t.Run("separate canary identity", func(t *testing.T) {
		runOnlineDriverCreateReserveDelete(t, "disk.dmstack-canary.csi.infinitydb.io", "localdisk.dmstack-canary.csi.infinitydb.io")
	})
}

func runOnlineDriverCreateReserveDelete(t *testing.T, originDriver, cacheDriver string) {
	f := newOnlineDriverFixture(t, originDriver, cacheDriver)
	ctrl := gomock.NewController(t)
	dc := mock_diskclient.NewMockInterface(ctrl)
	f.d.clientFactory.(*mock_azclient.MockClientFactory).EXPECT().GetDiskClientForSub(f.d.cloud.SubscriptionID).Return(dc, nil).AnyTimes()
	var mu sync.Mutex
	created := false
	disk := &armcompute.Disk{ID: &f.diskID, Properties: &armcompute.DiskProperties{UniqueID: ptr.To("azure-guid"), ProvisioningState: ptr.To("Succeeded"),
		DiskState: ptr.To(armcompute.DiskStateUnattached), DiskSizeBytes: ptr.To[int64](1 << 30), DiskSizeGB: ptr.To[int32](1), MaxShares: ptr.To[int32](1)}}
	dc.EXPECT().Get(gomock.Any(), f.d.cloud.ResourceGroup, "online-origin").DoAndReturn(func(context.Context, string, string) (*armcompute.Disk, error) {
		mu.Lock()
		defer mu.Unlock()
		if !created {
			return nil, &azcore.ResponseError{StatusCode: 404, ErrorCode: "ResourceNotFound"}
		}
		return disk, nil
	}).AnyTimes()
	dc.EXPECT().CreateOrUpdate(gomock.Any(), f.d.cloud.ResourceGroup, "online-origin", gomock.Any()).DoAndReturn(func(_ context.Context, _, _ string, in armcompute.Disk) (*armcompute.Disk, error) {
		require.Equal(t, armcompute.DiskCreateOptionEmpty, *in.Properties.CreationData.CreateOption)
		require.NotEmpty(t, ptr.Deref(in.Tags[devicelease.OnlineCreateTag], ""))
		mu.Lock()
		created = true
		disk.Tags = in.Tags
		disk.Properties.CreationData = in.Properties.CreationData
		mu.Unlock()
		return disk, nil
	}).Times(1)
	dc.EXPECT().Delete(gomock.Any(), f.d.cloud.ResourceGroup, "online-origin").Return(nil).Times(1)
	vm := setTestVirtualMachines(f.d.cloud, map[string]string{"vm1": "PowerState/Running"}, false)[0]
	vm.ID = &f.vmID
	vm.Properties.VMID = ptr.To("vm-guid")
	vm.Properties.OSProfile = &armcompute.OSProfile{ComputerName: vm.Name}
	vm.Properties.StorageProfile.DataDisks = nil
	vc := f.d.clientFactory.GetVirtualMachineClient().(*mockvm.MockInterface)
	vc.EXPECT().Get(gomock.Any(), f.d.cloud.ResourceGroup, "vm1", gomock.Any()).Return(&vm, nil).AnyTimes()
	native, provider := f.start(t)
	create := &csi.CreateVolumeRequest{Name: "online-origin", CapacityRange: &csi.CapacityRange{RequiredBytes: 1 << 30},
		VolumeCapabilities: []*csi.VolumeCapability{{AccessType: &csi.VolumeCapability_Block{Block: &csi.VolumeCapability_BlockVolume{}}, AccessMode: &csi.VolumeCapability_AccessMode{Mode: csi.VolumeCapability_AccessMode_SINGLE_NODE_WRITER}}},
		Parameters:         map[string]string{"skuName": "Standard_LRS", "csi.storage.k8s.io/pvc/namespace": "backing", "csi.storage.k8s.io/pvc/name": f.journal.Origin.Name}}
	made, err := native.CreateVolume(t.Context(), create)
	require.NoError(t, err)
	require.Equal(t, f.diskID, made.Volume.VolumeId)
	again, err := native.CreateVolume(t.Context(), create)
	require.NoError(t, err)
	require.True(t, proto.Equal(made, again), "native create replay must not issue a second ARM create")
	f.bind(t)
	f.kube.ClearActions()
	reserve := &pb.ReserveRequest{RequestId: "reserve-origin", CompositeVolumeId: f.id, Pool: &pb.Pool{Provider: f.cfg.Identity.ProviderID, PoolId: f.cfg.Identity.PoolID}, CapacityBytes: 1 << 30}
	lease, err := provider.Reserve(t.Context(), reserve)
	require.NoError(t, err)
	require.Equal(t, pb.LeaseState_LEASE_STATE_RESERVED, lease.State)
	fresh, err := f.d.onlineDomain.FreshOrigin(t.Context(), devicelease.Binding{AllocationID: lease.Allocation.Key.LeaseId, CompositeID: f.id, ResourceID: f.diskID,
		DiskUniqueID: lease.Allocation.StableDeviceId, DeviceGeneration: lease.Allocation.DeviceGeneration, CapacityBytes: int64(lease.CapacityBytes)})
	require.NoError(t, err)
	require.Equal(t, "azure-guid", fresh.DiskUniqueID)
	require.Equal(t, "Empty", fresh.CreateOption)
	require.Equal(t, f.journal.Origin.UID, fresh.PVCUID)
	require.Equal(t, f.journal.Owner, fresh.Owner)
	require.NotEmpty(t, fresh.OperationID)
	observed, err := provider.GetLease(t.Context(), lease.Allocation.Key)
	require.NoError(t, err)
	require.True(t, proto.Equal(lease, observed))
	_, err = native.DeleteVolume(t.Context(), &csi.DeleteVolumeRequest{VolumeId: f.diskID})
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	_, err = f.d.DeleteVolume(t.Context(), &csi.DeleteVolumeRequest{VolumeId: f.diskID})
	require.Equal(t, codes.FailedPrecondition, status.Code(err), "direct entry cannot bypass runtime admission")
	_, err = f.provider(t, f.nodeCert).Reserve(t.Context(), reserve)
	require.Equal(t, codes.PermissionDenied, status.Code(err))
	close := &pb.ReleaseRequest{RequestId: "close-origin", Allocation: lease.Allocation, Mode: pb.ReleaseMode_RELEASE_MODE_ALLOCATION}
	_, err = provider.Release(t.Context(), close)
	require.NoError(t, err)
	_, err = provider.GetLease(t.Context(), lease.Allocation.Key)
	require.Equal(t, codes.NotFound, status.Code(err))
	_, err = native.DeleteVolume(t.Context(), &csi.DeleteVolumeRequest{VolumeId: f.diskID})
	require.NoError(t, err)
	_, err = provider.Reserve(t.Context(), reserve)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	_, err = native.CreateVolume(t.Context(), create)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	for _, action := range f.kube.Actions() {
		if action.GetVerb() != "get" {
			require.Equal(t, "update", action.GetVerb())
			require.Equal(t, "configmaps", action.GetResource().Resource, "runtime may only write its admission journal")
		}
	}
}

func TestOnlineStartupRejectsMissingJournalAndWrongNode(t *testing.T) {
	for _, mode := range []string{"missing-journal", "wrong-node", "node-role", "bad-config"} {
		t.Run(mode, func(t *testing.T) {
			f := newOnlineDriverFixture(t)
			switch mode {
			case "missing-journal":
				require.NoError(t, f.kube.CoreV1().ConfigMaps("ns").Delete(t.Context(), "online", metav1.DeleteOptions{}))
			case "wrong-node":
				f.d.NodeID = "other-node"
			case "node-role":
				f.d.NodeID = "vm1"
			case "bad-config":
				require.NoError(t, os.Chmod(f.d.onlineConfigPath, 0600))
				require.NoError(t, os.WriteFile(f.d.onlineConfigPath, []byte(`{"unknown":true}`), 0600))
				require.NoError(t, os.Chmod(f.d.onlineConfigPath, 0444))
			}

			cfg, err := f.d.configureOnline(t.Context())
			if mode == "node-role" {
				require.NoError(t, err)
				require.NotNil(t, f.d.onlineDomain)
				server := grpc.NewServer()
				stop, err := f.d.startOnline(t.Context(), cfg, server)
				require.NoError(t, err)
				stop()
				listener, err := net.Listen("tcp", f.cfg.Endpoint)
				require.NoError(t, err, "node role must not bind controller's provider endpoint")
				require.NoError(t, listener.Close())
				_, err = f.d.NodeUnstageVolume(t.Context(), &csi.NodeUnstageVolumeRequest{VolumeId: f.diskID, StagingTargetPath: "untrusted"})
				require.Equal(t, codes.FailedPrecondition, status.Code(err))
			} else {
				require.Error(t, err)
				require.Nil(t, f.d.onlineDomain)
			}
		})
	}
}

func TestOnlineDriverDoesNotAdoptPreexistingDisk(t *testing.T) {
	f := newOnlineDriverFixture(t)
	ctrl := gomock.NewController(t)
	dc := mock_diskclient.NewMockInterface(ctrl)
	f.d.clientFactory.(*mock_azclient.MockClientFactory).EXPECT().GetDiskClientForSub(f.d.cloud.SubscriptionID).Return(dc, nil).AnyTimes()
	dc.EXPECT().Get(gomock.Any(), f.d.cloud.ResourceGroup, "online-origin").Return(&armcompute.Disk{ID: &f.diskID,
		Properties: &armcompute.DiskProperties{UniqueID: ptr.To("already-there"), ProvisioningState: ptr.To("Succeeded"),
			CreationData: &armcompute.CreationData{CreateOption: ptr.To(armcompute.DiskCreateOptionEmpty)}}}, nil).Times(1)
	native, _ := f.start(t)
	req := &csi.CreateVolumeRequest{Name: "online-origin", CapacityRange: &csi.CapacityRange{RequiredBytes: 1 << 30},
		VolumeCapabilities: []*csi.VolumeCapability{{AccessType: &csi.VolumeCapability_Block{Block: &csi.VolumeCapability_BlockVolume{}}, AccessMode: &csi.VolumeCapability_AccessMode{Mode: csi.VolumeCapability_AccessMode_SINGLE_NODE_WRITER}}},
		Parameters:         map[string]string{"skuName": "Standard_LRS", "csi.storage.k8s.io/pvc/namespace": "backing", "csi.storage.k8s.io/pvc/name": f.journal.Origin.Name}}
	_, err := native.CreateVolume(t.Context(), req)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	_, err = native.CreateVolume(t.Context(), req)
	require.Equal(t, codes.Unavailable, status.Code(err), "uncertain admission is retained, not converted to adoption on retry")
}
