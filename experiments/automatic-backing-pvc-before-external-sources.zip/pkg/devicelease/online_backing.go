/*
Copyright 2026 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package devicelease

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"regexp"
	"slices"
	"strings"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	core "k8s.io/api/core/v1"
	storage "k8s.io/api/storage/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/azuredisk-csi-driver/pkg/azureconstants"
	"sigs.k8s.io/azuredisk-csi-driver/pkg/azureutils"
)

const (
	backingPrefix     = "dmstack.csi.infinitydb.io/"
	backingJournalKey = backingPrefix + "backing-pvcs-v1"
	backingFinalizer  = backingPrefix + "backing-pvcs"
)

var (
	compositeGVR  = schema.GroupVersionResource{Group: "storage.infinitydb.io", Version: "v1alpha1", Resource: "compositevolumes"}
	compositeName = regexp.MustCompile(`^dmstack-[a-z2-7]{52}$`)
	compositeUID  = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_-]{0,66}$`)
)

type backingClaim struct {
	Name     string                    `json:"name"`
	UID      types.UID                 `json:"uid,omitempty"`
	ClassUID types.UID                 `json:"classUID"`
	Binding  storage.VolumeBindingMode `json:"binding"`
	PVName   string                    `json:"pvName,omitempty"`
	PVUID    types.UID                 `json:"pvUID,omitempty"`
	Handle   string                    `json:"handle,omitempty"`
}

type backingJournal struct {
	Config BackingConfig `json:"config"`
	Owner  string        `json:"owner"`
	Origin backingClaim  `json:"origin"`
	Cache  backingClaim  `json:"cache"`
}

func (j backingJournal) same(other backingJournal) bool {
	return j.Config.same(other.Config) && j.Owner == other.Owner && j.Origin == other.Origin && j.Cache == other.Cache
}

type backingProof struct {
	Journal                   backingJournal
	RequestID, Revision, VMID string
}

func backingIdentityError() error {
	return status.Error(codes.FailedPrecondition, "backing journal or live Kubernetes identity/specification mismatch")
}

func (d *OnlineDomain) checkDomainObjects(ctx context.Context) error {
	crd, err := d.dynamic.Resource(schema.GroupVersionResource{Group: "apiextensions.k8s.io", Version: "v1", Resource: "customresourcedefinitions"}).
		Get(ctx, "compositevolumes.storage.infinitydb.io", metav1.GetOptions{})
	if err != nil {
		return unavailable(err)
	}
	scope, _, _ := unstructured.NestedString(crd.Object, "spec", "scope")
	group, _, _ := unstructured.NestedString(crd.Object, "spec", "group")
	plural, _, _ := unstructured.NestedString(crd.Object, "spec", "names", "plural")
	kind, _, _ := unstructured.NestedString(crd.Object, "spec", "names", "kind")
	if crd.GetUID() != d.identity.CompositeCRDUID || crd.GetDeletionTimestamp() != nil ||
		scope != "Cluster" || group != compositeGVR.Group || plural != compositeGVR.Resource || kind != "CompositeVolume" {
		return backingIdentityError()
	}
	versions, _, _ := unstructured.NestedSlice(crd.Object, "spec", "versions")
	served := false
	for _, v := range versions {
		m, ok := v.(map[string]any)
		served = served || ok && m["name"] == compositeGVR.Version && m["served"] == true
	}
	if !served {
		return backingIdentityError()
	}
	return nil
}

func (d *OnlineDomain) checkScope(ctx context.Context) (*core.Namespace, *core.Node, error) {
	c := d.identity.Backing
	ns, err := d.kube.CoreV1().Namespaces().Get(ctx, c.Namespace, metav1.GetOptions{})
	if err != nil {
		return nil, nil, unavailable(err)
	}
	node, err := d.kube.CoreV1().Nodes().Get(ctx, c.NodeName, metav1.GetOptions{})
	if err != nil {
		return nil, nil, unavailable(err)
	}
	if ns.UID != c.NamespaceUID || ns.DeletionTimestamp != nil || ns.Labels[backingPrefix+"backing-namespace"] != "v1" || len(ns.OwnerReferences) != 0 ||
		node.UID != c.NodeUID || node.DeletionTimestamp != nil || node.Spec.Unschedulable || !strings.HasPrefix(node.Spec.ProviderID, "azure://") {
		return nil, nil, backingIdentityError()
	}
	return ns, node, nil
}

func (d *OnlineDomain) resolveBacking(ctx context.Context, id string, bound bool) (backingProof, error) {
	var out backingProof
	if !compositeName.MatchString(id) {
		return out, backingIdentityError()
	}
	if err := d.checkDomainObjects(ctx); err != nil {
		return out, err
	}
	v, err := d.dynamic.Resource(compositeGVR).Get(ctx, id, metav1.GetOptions{})
	if err != nil {
		return out, unavailable(err)
	}
	if v.GetAPIVersion() != "storage.infinitydb.io/v1alpha1" || v.GetKind() != "CompositeVolume" ||
		v.GetName() != id || v.GetNamespace() != "" || !compositeUID.MatchString(string(v.GetUID())) ||
		v.GetResourceVersion() == "" || v.GetDeletionTimestamp() != nil || !slices.Contains(v.GetFinalizers(), backingFinalizer) {
		return out, backingIdentityError()
	}
	raw := v.GetAnnotations()[backingJournalKey]
	if json.Unmarshal([]byte(raw), &out.Journal) != nil {
		return out, backingIdentityError()
	}
	j := out.Journal
	canonical, _ := json.Marshal(j)
	c := d.identity.Backing
	originSize, _, _ := unstructured.NestedInt64(v.Object, "spec", "capacity")
	cacheSize, _, _ := unstructured.NestedInt64(v.Object, "spec", "cacheBytes")
	provider, _, _ := unstructured.NestedString(v.Object, "spec", "originParameters", "provider")
	pool, _, _ := unstructured.NestedString(v.Object, "spec", "originParameters", "poolID")
	request, _, _ := unstructured.NestedString(v.Object, "spec", "originParameters", "requestID")
	if string(canonical) != raw || !j.Config.same(c) || j.Owner != id+"."+string(v.GetUID()) ||
		v.GetAnnotations()[backingPrefix+"selected-node"] != c.NodeName ||
		originSize != c.OriginBytes || cacheSize != c.CacheBytes || provider != d.identity.ProviderID || pool != d.identity.PoolID || !validID(request) {
		return out, backingIdentityError()
	}
	ns, node, err := d.checkScope(ctx)
	if err != nil {
		return out, err
	}
	revisions := []string{v.GetResourceVersion(), ns.ResourceVersion, node.ResourceVersion}
	for _, side := range []struct {
		role, class, driver string
		bytes               int64
		pin                 backingClaim
	}{
		{"origin", c.OriginStorageClass, c.EffectiveOriginDriver(), c.OriginBytes, j.Origin},
		{"cache", c.CacheStorageClass, c.EffectiveCacheDriver(), c.CacheBytes, j.Cache},
	} {
		sum := sha256.Sum256([]byte(j.Owner))
		if side.pin.Name != fmt.Sprintf("dmstack-%x-%s", sum[:20], side.role) || side.pin.ClassUID == "" {
			return out, backingIdentityError()
		}
		sc, err := d.kube.StorageV1().StorageClasses().Get(ctx, side.class, metav1.GetOptions{})
		if err != nil {
			return out, unavailable(err)
		}
		if sc.UID != side.pin.ClassUID || sc.DeletionTimestamp != nil || sc.Provisioner != side.driver || sc.VolumeBindingMode == nil ||
			*sc.VolumeBindingMode != side.pin.Binding || side.pin.Binding != storage.VolumeBindingImmediate && side.pin.Binding != storage.VolumeBindingWaitForFirstConsumer ||
			!backingTopology(sc.AllowedTopologies, node) {
			return out, backingIdentityError()
		}
		revisions = append(revisions, sc.ResourceVersion)
		// During native origin creation the other claim need not exist yet.
		if !bound && side.role == "cache" {
			continue
		}
		pvc, err := d.kube.CoreV1().PersistentVolumeClaims(c.Namespace).Get(ctx, side.pin.Name, metav1.GetOptions{})
		if err != nil {
			return out, unavailable(err)
		}
		selected := pvc.Annotations["volume.kubernetes.io/selected-node"]
		requested := pvc.Spec.Resources.Requests[core.ResourceStorage]
		if side.pin.UID == "" || pvc.UID != side.pin.UID || pvc.ResourceVersion == "" || pvc.DeletionTimestamp != nil ||
			pvc.Annotations[backingPrefix+"composite-handle"] != j.Owner || pvc.Annotations[backingPrefix+"backing-role"] != side.role ||
			len(pvc.OwnerReferences) != 0 || !slices.Contains(pvc.Finalizers, backingFinalizer) ||
			pvc.Spec.StorageClassName == nil || *pvc.Spec.StorageClassName != side.class || pvc.Spec.VolumeMode == nil || *pvc.Spec.VolumeMode != core.PersistentVolumeBlock ||
			!slices.Equal(pvc.Spec.AccessModes, []core.PersistentVolumeAccessMode{core.ReadWriteOnce}) || requested.Cmp(*resource.NewQuantity(side.bytes, resource.BinarySI)) != 0 ||
			len(pvc.Spec.Resources.Limits) != 0 || pvc.Spec.Selector != nil || pvc.Spec.DataSource != nil || pvc.Spec.DataSourceRef != nil || pvc.Spec.VolumeAttributesClassName != nil ||
			selected != "" && selected != node.Name || side.pin.Binding == storage.VolumeBindingWaitForFirstConsumer && selected != node.Name ||
			side.role == "cache" && pvc.Annotations["localdisk.csi.acstor.io/accept-ephemeral-storage"] != "true" {
			return out, backingIdentityError()
		}
		revisions = append(revisions, pvc.ResourceVersion)
		if !bound {
			if pvc.Status.Phase != core.ClaimPending || pvc.Spec.VolumeName != "" || side.pin.PVUID != "" || side.pin.PVName != "" || side.pin.Handle != "" {
				return out, backingIdentityError()
			}
			continue
		}
		if pvc.Status.Phase != core.ClaimBound || pvc.Spec.VolumeName != side.pin.PVName || side.pin.PVUID == "" || side.pin.Handle == "" {
			return out, backingIdentityError()
		}
		pv, err := d.kube.CoreV1().PersistentVolumes().Get(ctx, side.pin.PVName, metav1.GetOptions{})
		if err != nil {
			return out, unavailable(err)
		}
		capacity, claimCapacity := pv.Spec.Capacity[core.ResourceStorage], pvc.Status.Capacity[core.ResourceStorage]
		if pv.UID != side.pin.PVUID || pv.DeletionTimestamp != nil || pv.Status.Phase != core.VolumeBound ||
			pv.Spec.ClaimRef == nil || pv.Spec.ClaimRef.UID != pvc.UID || pv.Spec.ClaimRef.Name != pvc.Name || pv.Spec.ClaimRef.Namespace != pvc.Namespace ||
			pv.Spec.CSI == nil || pv.Spec.CSI.Driver != side.driver || pv.Spec.CSI.VolumeHandle != side.pin.Handle || pv.Spec.CSI.ReadOnly ||
			pv.Spec.StorageClassName != side.class || pv.Spec.VolumeMode == nil || *pv.Spec.VolumeMode != core.PersistentVolumeBlock ||
			!slices.Equal(pv.Spec.AccessModes, pvc.Spec.AccessModes) || capacity.Cmp(*resource.NewQuantity(side.bytes, resource.BinarySI)) != 0 || claimCapacity.Cmp(capacity) != 0 ||
			!backingAffinity(pv.Spec.NodeAffinity, node) {
			return out, backingIdentityError()
		}
		if side.role == "origin" {
			mode, _ := azureutils.ParseDiskParametersForKey(pv.Spec.CSI.VolumeAttributes, azureconstants.AttachModeField)
			shares, err := azureutils.GetMaxShares(pv.Spec.CSI.VolumeAttributes)
			if err != nil || shares != 1 || mode != "" && !strings.EqualFold(mode, azureconstants.AttachModeControllerDriven) {
				return out, backingIdentityError()
			}
		}
		revisions = append(revisions, pv.ResourceVersion)
	}
	if bound && (j.Origin.PVName == j.Cache.PVName || j.Origin.Handle == j.Cache.Handle) {
		return out, backingIdentityError()
	}
	out.RequestID = request
	out.VMID = strings.TrimPrefix(node.Spec.ProviderID, "azure://")
	data, _ := json.Marshal(revisions)
	out.Revision = blockRequestDigest(string(data))
	return out, nil
}

func (d *OnlineDomain) CreationOwner(ctx context.Context, namespace, name string, bytes int64) (string, string, error) {
	if namespace != d.identity.Backing.Namespace || name == "" || bytes != d.identity.Backing.OriginBytes {
		return "", "", backingIdentityError()
	}
	pvc, err := d.kube.CoreV1().PersistentVolumeClaims(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return "", "", unavailable(err)
	}
	id, _, ok := strings.Cut(pvc.Annotations[backingPrefix+"composite-handle"], ".")
	if !ok {
		return "", "", backingIdentityError()
	}
	proof, err := d.resolveBacking(ctx, id, false)
	if err != nil {
		return "", "", err
	}
	if proof.Journal.Origin.Name != name || proof.Journal.Origin.UID != pvc.UID {
		return "", "", backingIdentityError()
	}
	return id, proof.Journal.Owner, nil
}

func backingTopology(terms []core.TopologySelectorTerm, node *core.Node) bool {
	if len(terms) == 0 {
		return true
	}
	for _, term := range terms {
		match := len(term.MatchLabelExpressions) > 0
		for _, expr := range term.MatchLabelExpressions {
			match = match && slices.Contains(expr.Values, node.Labels[expr.Key])
		}
		if match {
			return true
		}
	}
	return false
}

func backingAffinity(affinity *core.VolumeNodeAffinity, node *core.Node) bool {
	if affinity == nil || affinity.Required == nil {
		return false
	}
	for _, term := range affinity.Required.NodeSelectorTerms {
		match := len(term.MatchExpressions)+len(term.MatchFields) > 0
		for _, expr := range term.MatchExpressions {
			match = match && expr.Operator == core.NodeSelectorOpIn && slices.Contains(expr.Values, node.Labels[expr.Key])
		}
		for _, expr := range term.MatchFields {
			match = match && expr.Key == "metadata.name" && expr.Operator == core.NodeSelectorOpIn && slices.Contains(expr.Values, node.Name)
		}
		if match {
			return true
		}
	}
	return false
}
