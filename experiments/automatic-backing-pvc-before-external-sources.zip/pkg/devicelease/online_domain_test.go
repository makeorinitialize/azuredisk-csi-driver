/*
Copyright 2026 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package devicelease

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"sync"
	"testing"

	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/compute/armcompute/v7"
	"github.com/container-storage-interface/spec/lib/go/csi"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"
	core "k8s.io/api/core/v1"
	storage "k8s.io/api/storage/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/dynamic"
	ktesting "k8s.io/client-go/testing"
	"k8s.io/utils/ptr"
	pb "sigs.k8s.io/azuredisk-csi-driver/pkg/devicelease/api/v1"
)

type onlineDynamic struct {
	dynamic.Interface
	mu      sync.Mutex
	objects map[string]*unstructured.Unstructured
}

type onlineResource struct {
	dynamic.NamespaceableResourceInterface
	client *onlineDynamic
	gvr    schema.GroupVersionResource
}

func (c *onlineDynamic) Resource(gvr schema.GroupVersionResource) dynamic.NamespaceableResourceInterface {
	return &onlineResource{client: c, gvr: gvr}
}

func (r *onlineResource) Get(_ context.Context, name string, _ metav1.GetOptions, _ ...string) (*unstructured.Unstructured, error) {
	r.client.mu.Lock()
	defer r.client.mu.Unlock()
	o := r.client.objects[r.gvr.String()+"/"+name]
	if o == nil {
		return nil, errors.New("source object absent")
	}
	return o.DeepCopy(), nil
}

func (r *onlineResource) Update(_ context.Context, o *unstructured.Unstructured, _ metav1.UpdateOptions, _ ...string) (*unstructured.Unstructured, error) {
	r.client.mu.Lock()
	defer r.client.mu.Unlock()
	key := r.gvr.String() + "/" + o.GetName()
	old := r.client.objects[key]
	if old == nil {
		return nil, errors.New("source object absent")
	}
	version, _ := strconv.Atoi(old.GetResourceVersion())
	copy := o.DeepCopy()
	copy.SetResourceVersion(strconv.Itoa(version + 1))
	r.client.objects[key] = copy
	return copy.DeepCopy(), nil
}

type onlineFixture struct {
	f    *reservationFixture
	d    *OnlineDomain
	dyn  *onlineDynamic
	cv   *unstructured.Unstructured
	j    backingJournal
	req  *pb.ReserveRequest
	disk *armcompute.Disk
	vm   TargetVM
	ca   tls.Certificate
}

func newOnlineFixture(t *testing.T, drivers ...string) *onlineFixture {
	t.Helper()
	f := fixture(t, "pin")
	cfg := OnlineIdentity{ProviderID: "azure-canary-origin", PoolID: "bound-block-one", CompositeCRDUID: "crd-uid",
		Backing: BackingConfig{Namespace: "backing", NamespaceUID: "ns-uid", NodeName: "vm1", NodeUID: "node-uid",
			OriginStorageClass: "azure-block", CacheStorageClass: "acs-block", OriginBytes: gib, CacheBytes: gib}}
	if len(drivers) != 0 {
		require.Len(t, drivers, 2)
		cfg.Backing.OriginDriver, cfg.Backing.CacheDriver = drivers[0], drivers[1]
	}
	id := "dmstack-" + strings.Repeat("a", 52)
	j := backingJournal{Config: cfg.Backing, Owner: id + ".composite-uid"}
	for role, pin := range map[string]*backingClaim{"origin": &j.Origin, "cache": &j.Cache} {
		sum := sha256.Sum256([]byte(j.Owner))
		*pin = backingClaim{Name: fmt.Sprintf("dmstack-%x-%s", sum[:20], role), UID: types.UID(role + "-pvc-uid"), ClassUID: types.UID(role + "-sc-uid"), Binding: storage.VolumeBindingImmediate}
	}
	data, err := json.Marshal(j)
	require.NoError(t, err)
	cv := &unstructured.Unstructured{Object: map[string]any{
		"apiVersion": "storage.infinitydb.io/v1alpha1", "kind": "CompositeVolume",
		"metadata": map[string]any{"name": id, "uid": "composite-uid", "resourceVersion": "1",
			"annotations": map[string]any{backingJournalKey: string(data), backingPrefix + "selected-node": "vm1"},
			"finalizers":  []any{backingFinalizer}},
		"spec": map[string]any{"capacity": int64(gib), "cacheBytes": int64(gib),
			"originParameters": map[string]any{"provider": cfg.ProviderID, "poolID": cfg.PoolID, "requestID": "reserve-origin"}}}}
	crd := &unstructured.Unstructured{Object: map[string]any{"apiVersion": "apiextensions.k8s.io/v1", "kind": "CustomResourceDefinition",
		"metadata": map[string]any{"name": "compositevolumes.storage.infinitydb.io", "uid": "crd-uid"},
		"spec": map[string]any{"scope": "Cluster", "group": "storage.infinitydb.io", "names": map[string]any{"plural": "compositevolumes", "kind": "CompositeVolume"},
			"versions": []any{map[string]any{"name": "v1alpha1", "served": true}}}}}
	dyn := &onlineDynamic{objects: map[string]*unstructured.Unstructured{
		compositeGVR.String() + "/" + id: cv.DeepCopy(),
		(schema.GroupVersionResource{Group: "apiextensions.k8s.io", Version: "v1", Resource: "customresourcedefinitions"}).String() + "/" + crd.GetName(): crd.DeepCopy(),
	}}
	_, err = f.client.CoreV1().Namespaces().Create(t.Context(), &core.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "backing", UID: "ns-uid", ResourceVersion: "1",
		Labels: map[string]string{backingPrefix + "backing-namespace": "v1"}}}, metav1.CreateOptions{})
	require.NoError(t, err)
	_, err = f.client.CoreV1().Nodes().Create(t.Context(), &core.Node{ObjectMeta: metav1.ObjectMeta{Name: "vm1", UID: "node-uid", ResourceVersion: "1"},
		Spec: core.NodeSpec{ProviderID: "azure:///subscriptions/sub/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/vm1"}}, metav1.CreateOptions{})
	require.NoError(t, err)
	for _, side := range []struct {
		class, driver, role string
		pin                 backingClaim
	}{
		{"azure-block", cfg.Backing.EffectiveOriginDriver(), "origin", j.Origin}, {"acs-block", cfg.Backing.EffectiveCacheDriver(), "cache", j.Cache},
	} {
		_, err = f.client.StorageV1().StorageClasses().Create(t.Context(), &storage.StorageClass{ObjectMeta: metav1.ObjectMeta{Name: side.class, UID: side.pin.ClassUID, ResourceVersion: "1"},
			Provisioner: side.driver, VolumeBindingMode: ptr.To(storage.VolumeBindingImmediate)}, metav1.CreateOptions{})
		require.NoError(t, err)
		pvc := &core.PersistentVolumeClaim{ObjectMeta: metav1.ObjectMeta{Namespace: "backing", Name: side.pin.Name, UID: side.pin.UID, ResourceVersion: "1",
			Annotations: map[string]string{backingPrefix + "composite-handle": j.Owner, backingPrefix + "backing-role": side.role}, Finalizers: []string{backingFinalizer}},
			Spec: core.PersistentVolumeClaimSpec{StorageClassName: &side.class, VolumeMode: ptr.To(core.PersistentVolumeBlock), AccessModes: []core.PersistentVolumeAccessMode{core.ReadWriteOnce},
				Resources: core.VolumeResourceRequirements{Requests: core.ResourceList{core.ResourceStorage: resource.MustParse("1Gi")}}},
			Status: core.PersistentVolumeClaimStatus{Phase: core.ClaimPending}}
		if side.role == "cache" {
			pvc.Annotations["localdisk.csi.acstor.io/accept-ephemeral-storage"] = "true"
		}
		_, err = f.client.CoreV1().PersistentVolumeClaims("backing").Create(t.Context(), pvc, metav1.CreateOptions{})
		require.NoError(t, err)
	}
	initial, err := InitialOnlineDomain(cfg)
	require.NoError(t, err)
	_, err = f.client.CoreV1().ConfigMaps("ns").Create(t.Context(), &core.ConfigMap{ObjectMeta: metav1.ObjectMeta{Name: "online", Namespace: "ns", UID: "online-uid", ResourceVersion: "1"}, Data: initial}, metav1.CreateOptions{})
	require.NoError(t, err)
	d, err := NewOnlineDomain(cfg, f.client.CoreV1().ConfigMaps("ns"), "online", "online-uid", f.client, dyn)
	require.NoError(t, err)
	vm := TargetVM{ID: "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/vm1", InstanceGUID: "vm-guid", ProvisioningState: "Succeeded"}
	return &onlineFixture{f: f, d: d, dyn: dyn, cv: cv, j: j, req: &pb.ReserveRequest{RequestId: "reserve-origin", CompositeVolumeId: id,
		Pool: &pb.Pool{Provider: cfg.ProviderID, PoolId: cfg.PoolID}, CapacityBytes: uint64(gib)}, vm: vm,
		disk: &armcompute.Disk{ID: ptr.To(resourceID), Properties: &armcompute.DiskProperties{UniqueID: ptr.To("azure-guid"), DiskSizeBytes: ptr.To(int64(gib)),
			MaxShares: ptr.To[int32](1), ProvisioningState: ptr.To("Succeeded"), DiskState: ptr.To(armcompute.DiskStateUnattached)}}, ca: testCert(t, 1, nil, false)}
}

func (f *onlineFixture) create(t *testing.T) {
	t.Helper()
	id, owner, err := f.d.CreationOwner(t.Context(), "backing", f.j.Origin.Name, gib)
	require.NoError(t, err)
	ctx, hold, err := f.d.BeginNative(t.Context(), "CreateVolume", "create", "", id, owner)
	require.NoError(t, err)
	require.Nil(t, hold)
	require.NoError(t, f.d.RecordCreateTarget(ctx, resourceID))
	tag, err := f.d.NativeCreateTag(ctx)
	require.NoError(t, err)
	f.disk.Tags = map[string]*string{OnlineCreateTag: &tag}
	f.disk.Properties.CreationData = &armcompute.CreationData{CreateOption: ptr.To(armcompute.DiskCreateOptionEmpty)}
	require.NoError(t, f.d.ConfirmFreshCreate(ctx, f.disk))
	response, err := proto.Marshal(&csi.CreateVolumeResponse{Volume: &csi.Volume{VolumeId: resourceID, CapacityBytes: gib}})
	require.NoError(t, err)
	require.NoError(t, f.d.EndNative(ctx, true, resourceID, response))
}

func (f *onlineFixture) bind(t *testing.T) {
	t.Helper()
	for role, pin := range map[string]*backingClaim{"origin": &f.j.Origin, "cache": &f.j.Cache} {
		class, driver, handle := "azure-block", f.d.identity.Backing.EffectiveOriginDriver(), resourceID
		if role == "cache" {
			class, driver, handle = "acs-block", f.d.identity.Backing.EffectiveCacheDriver(), "vg#pv"
		}
		pin.PVName, pin.PVUID, pin.Handle = role+"-pv", types.UID(role+"-pv-uid"), handle
		pvc, err := f.f.client.CoreV1().PersistentVolumeClaims("backing").Get(t.Context(), pin.Name, metav1.GetOptions{})
		require.NoError(t, err)
		pvc.Spec.VolumeName = pin.PVName
		pvc.Status.Phase = core.ClaimBound
		pvc.Status.Capacity = core.ResourceList{core.ResourceStorage: resource.MustParse("1Gi")}
		_, err = f.f.client.CoreV1().PersistentVolumeClaims("backing").Update(t.Context(), pvc, metav1.UpdateOptions{})
		require.NoError(t, err)
		pv := &core.PersistentVolume{ObjectMeta: metav1.ObjectMeta{Name: pin.PVName, UID: pin.PVUID, ResourceVersion: "1"}, Spec: core.PersistentVolumeSpec{
			StorageClassName: class, VolumeMode: ptr.To(core.PersistentVolumeBlock), AccessModes: []core.PersistentVolumeAccessMode{core.ReadWriteOnce},
			Capacity: core.ResourceList{core.ResourceStorage: resource.MustParse("1Gi")}, ClaimRef: &core.ObjectReference{Name: pin.Name, Namespace: "backing", UID: pin.UID},
			PersistentVolumeSource: core.PersistentVolumeSource{CSI: &core.CSIPersistentVolumeSource{Driver: driver, VolumeHandle: handle}},
			NodeAffinity:           &core.VolumeNodeAffinity{Required: &core.NodeSelector{NodeSelectorTerms: []core.NodeSelectorTerm{{MatchFields: []core.NodeSelectorRequirement{{Key: "metadata.name", Operator: core.NodeSelectorOpIn, Values: []string{"vm1"}}}}}}}},
			Status: core.PersistentVolumeStatus{Phase: core.VolumeBound}}
		_, err = f.f.client.CoreV1().PersistentVolumes().Create(t.Context(), pv, metav1.CreateOptions{})
		require.NoError(t, err)
	}
	data, err := json.Marshal(f.j)
	require.NoError(t, err)
	annotations := f.cv.GetAnnotations()
	annotations[backingJournalKey] = string(data)
	f.cv.SetAnnotations(annotations)
	_, err = f.dyn.Resource(compositeGVR).Update(t.Context(), f.cv, metav1.UpdateOptions{})
	require.NoError(t, err)
}

func (f *onlineFixture) connect(t *testing.T, role ReservationRole) pb.DeviceProviderClient {
	t.Helper()
	clientCert := testCert(t, 2, &f.ca, false)
	digest := sha256.Sum256(clientCert.Certificate[0])
	roots := x509.NewCertPool()
	roots.AddCert(f.ca.Leaf)
	node := ""
	if role == ReservationNode {
		node = "vm1"
	}
	server, err := NewOnlineServer(f.d, func(context.Context, BlockSelection) (*armcompute.Disk, TargetVM, error) { return f.disk, f.vm, nil },
		testCert(t, 3, &f.ca, true), roots, []OnlineGrant{{hex.EncodeToString(digest[:]), role, node}})
	require.NoError(t, err)
	lis, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	go func() { _ = server.Serve(lis) }()
	t.Cleanup(server.Stop)
	conn, err := grpc.NewClient(lis.Addr().String(), grpc.WithTransportCredentials(credentials.NewTLS(&tls.Config{MinVersion: tls.VersionTLS13, RootCAs: roots, ServerName: "origin.provider.example", Certificates: []tls.Certificate{clientCert}})))
	require.NoError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	return pb.NewDeviceProviderClient(conn)
}

func (f *onlineFixture) restart(t *testing.T) {
	t.Helper()
	var err error
	f.d, err = NewOnlineDomain(f.d.identity, f.d.maps, f.d.name, f.d.uid, f.f.client, f.dyn)
	require.NoError(t, err)
}

func TestOnlineReserveClosureWire(t *testing.T) {
	f := newOnlineFixture(t)
	require.NoError(t, f.d.Check(t.Context()))
	_, _, err := f.d.BeginNative(t.Context(), "ControllerPublishVolume", "publish", resourceID, "", "")
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	f.create(t)
	f.bind(t)
	client := f.connect(t, ReservationController)
	lease, err := client.Reserve(t.Context(), f.req)
	require.NoError(t, err)
	require.Equal(t, pb.LeaseState_LEASE_STATE_RESERVED, lease.State)
	require.Zero(t, lease.OwnerEpoch)
	require.Equal(t, resourceID, lease.Allocation.ResourceId)
	require.Equal(t, f.req.Pool.Provider, lease.Allocation.Key.Provider)
	require.Equal(t, f.req.Pool.PoolId, lease.PoolId)
	require.Equal(t, "azure-guid", lease.Allocation.StableDeviceId)
	_, _, err = f.d.BeginNative(t.Context(), "DeleteVolume", "delete", resourceID, "", "")
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	node := f.connect(t, ReservationNode)
	_, err = node.Reserve(t.Context(), f.req)
	require.Equal(t, codes.PermissionDenied, status.Code(err))
	_, err = node.Acquire(t.Context(), &pb.AcquireRequest{RequestId: "acquire", Owner: &pb.Owner{Allocation: lease.Allocation, NodeId: "vm1", OwnerEpoch: 1}})
	require.Equal(t, codes.FailedPrecondition, status.Code(err), "registration alone never proves publication")
	f.cv.SetDeletionTimestamp(ptr.To(metav1.Now()))
	_, err = f.dyn.Resource(compositeGVR).Update(t.Context(), f.cv, metav1.UpdateOptions{})
	require.NoError(t, err)
	f.restart(t)
	client = f.connect(t, ReservationController)
	replay, err := client.Reserve(t.Context(), f.req)
	require.NoError(t, err, "deletion must not strand an already committed receipt")
	require.True(t, proto.Equal(lease, replay))
	release := &pb.ReleaseRequest{RequestId: "close", Allocation: lease.Allocation, Mode: pb.ReleaseMode_RELEASE_MODE_ALLOCATION}
	_, err = client.Release(t.Context(), release)
	require.NoError(t, err)
	_, err = client.GetLease(t.Context(), lease.Allocation.Key)
	require.Equal(t, codes.NotFound, status.Code(err))
	f.restart(t)
	client = f.connect(t, ReservationController)
	_, err = client.Release(t.Context(), release)
	require.NoError(t, err)
	_, err = client.Reserve(t.Context(), f.req)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	ctx, hold, err := f.d.BeginNative(t.Context(), "DeleteVolume", "delete", resourceID, "", "")
	require.NoError(t, err)
	require.NoError(t, hold.EnterTeardown(ctx))
	require.NoError(t, f.d.EndNative(ctx, true, "", nil))
	_, _, err = f.d.BeginNative(t.Context(), "ControllerPublishVolume", "late-publish", resourceID, "", "")
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
}

func TestOnlineNativeAdmissionRetainedAcrossRestart(t *testing.T) {
	for _, complete := range []bool{false, true} {
		t.Run(fmt.Sprint(complete), func(t *testing.T) {
			f := newOnlineFixture(t)
			ctx, _, err := f.d.BeginNative(t.Context(), "CreateVolume", "create", "", f.req.CompositeVolumeId, f.j.Owner)
			require.NoError(t, err)
			if complete {
				require.NoError(t, f.d.EndNative(ctx, false, "", nil))
			}
			f.bind(t)
			f.restart(t)
			_, err = f.connect(t, ReservationController).Reserve(t.Context(), f.req)
			require.Equal(t, codes.Unavailable, status.Code(err))
			_, _, err = f.d.BeginNative(t.Context(), "DeleteVolume", "delete", resourceID, "", "")
			require.Equal(t, codes.Unavailable, status.Code(err))
			_, r, err := f.d.read(t.Context())
			require.NoError(t, err)
			require.NotNil(t, r.Busy)
			require.Nil(t, r.Selection)
		})
	}
}

func TestOnlineDeleteBeforeRegistrationFencesLateReserve(t *testing.T) {
	f := newOnlineFixture(t)
	f.create(t)
	f.bind(t)
	ctx, _, err := f.d.BeginNative(t.Context(), "DeleteVolume", "delete", resourceID, "", "")
	require.NoError(t, err)
	require.NoError(t, f.d.EndNative(ctx, true, "", nil))
	f.restart(t)
	_, err = f.connect(t, ReservationController).Reserve(t.Context(), f.req)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
}

func TestOnlineBackingReplacementsCannotEnroll(t *testing.T) {
	for _, mutation := range []string{"node", "namespace", "class", "pvc", "pv", "handle", "deleting", "no-native-creation", "disk-guid", "attached"} {
		t.Run(mutation, func(t *testing.T) {
			f := newOnlineFixture(t)
			if mutation != "no-native-creation" {
				f.create(t)
			}
			f.bind(t)
			switch mutation {
			case "node":
				x, err := f.f.client.CoreV1().Nodes().Get(t.Context(), "vm1", metav1.GetOptions{})
				require.NoError(t, err)
				x.UID = "replacement"
				_, err = f.f.client.CoreV1().Nodes().Update(t.Context(), x, metav1.UpdateOptions{})
				require.NoError(t, err)
			case "namespace":
				x, err := f.f.client.CoreV1().Namespaces().Get(t.Context(), "backing", metav1.GetOptions{})
				require.NoError(t, err)
				x.UID = "replacement"
				_, err = f.f.client.CoreV1().Namespaces().Update(t.Context(), x, metav1.UpdateOptions{})
				require.NoError(t, err)
			case "class":
				x, err := f.f.client.StorageV1().StorageClasses().Get(t.Context(), "azure-block", metav1.GetOptions{})
				require.NoError(t, err)
				x.UID = "replacement"
				_, err = f.f.client.StorageV1().StorageClasses().Update(t.Context(), x, metav1.UpdateOptions{})
				require.NoError(t, err)
			case "pvc":
				x, err := f.f.client.CoreV1().PersistentVolumeClaims("backing").Get(t.Context(), f.j.Origin.Name, metav1.GetOptions{})
				require.NoError(t, err)
				x.UID = "replacement"
				_, err = f.f.client.CoreV1().PersistentVolumeClaims("backing").Update(t.Context(), x, metav1.UpdateOptions{})
				require.NoError(t, err)
			case "pv", "handle":
				x, err := f.f.client.CoreV1().PersistentVolumes().Get(t.Context(), f.j.Origin.PVName, metav1.GetOptions{})
				require.NoError(t, err)
				if mutation == "pv" {
					x.UID = "replacement"
				} else {
					x.Spec.CSI.VolumeHandle = strings.ToUpper(resourceID)
				}
				_, err = f.f.client.CoreV1().PersistentVolumes().Update(t.Context(), x, metav1.UpdateOptions{})
				require.NoError(t, err)
			case "deleting":
				f.cv.SetDeletionTimestamp(ptr.To(metav1.Now()))
				_, err := f.dyn.Resource(compositeGVR).Update(t.Context(), f.cv, metav1.UpdateOptions{})
				require.NoError(t, err)
			case "disk-guid":
				f.disk.Properties.UniqueID = nil
			case "attached":
				f.disk.ManagedBy = &f.vm.ID
			}
			before, _, err := f.d.read(t.Context())
			require.NoError(t, err)
			_, err = f.connect(t, ReservationController).Reserve(t.Context(), f.req)
			require.Error(t, err)
			after, _, err := f.d.read(t.Context())
			require.NoError(t, err)
			require.Equal(t, before, after, "rejected discovery must not consume journal state")
		})
	}
}

func TestOnlineLostReserveAndClosureReplies(t *testing.T) {
	f := newOnlineFixture(t)
	f.create(t)
	f.bind(t)
	loss := true
	f.f.client.PrependReactor("update", "configmaps", func(action ktesting.Action) (bool, runtime.Object, error) {
		if !loss {
			return false, nil, nil
		}

		next := action.(ktesting.UpdateAction).GetObject().(*core.ConfigMap).DeepCopy()
		var r onlineRecord
		require.NoError(t, json.Unmarshal([]byte(next.Data[onlineDomainKey]), &r))
		if r.Selection == nil {
			return false, nil, nil
		}
		loss = false
		version, err := strconv.Atoi(next.ResourceVersion)
		require.NoError(t, err)
		next.ResourceVersion = strconv.Itoa(version + 1)
		require.NoError(t, f.f.client.Tracker().Update(schema.GroupVersionResource{Version: "v1", Resource: "configmaps"}, next, next.Namespace))
		return true, nil, errors.New("lost successful CAS reply")
	})
	client := f.connect(t, ReservationController)
	_, err := client.Reserve(t.Context(), f.req)
	require.Equal(t, codes.Unavailable, status.Code(err))
	f.restart(t)
	client = f.connect(t, ReservationController)
	lease, err := client.Reserve(t.Context(), f.req)
	require.NoError(t, err)
	loss = true
	close := &pb.ReleaseRequest{RequestId: "close", Allocation: lease.Allocation, Mode: pb.ReleaseMode_RELEASE_MODE_ALLOCATION}
	_, err = client.Release(t.Context(), close)
	require.Equal(t, codes.Unavailable, status.Code(err))
	f.restart(t)
	client = f.connect(t, ReservationController)
	_, err = client.Release(t.Context(), close)
	require.NoError(t, err)
	_, err = client.GetLease(t.Context(), lease.Allocation.Key)
	require.Equal(t, codes.NotFound, status.Code(err))
}

func TestOnlineFreshOriginProofRequiredBeforeCreateSuccess(t *testing.T) {
	for _, bad := range []string{"missing-tag", "changed-tag", "clone", "missing-guid", "wrong-size", "updating"} {
		t.Run(bad, func(t *testing.T) {
			f := newOnlineFixture(t)
			ctx, _, err := f.d.BeginNative(t.Context(), "CreateVolume", "create", "", f.req.CompositeVolumeId, f.j.Owner)
			require.NoError(t, err)
			require.NoError(t, f.d.RecordCreateTarget(ctx, resourceID))
			tag, err := f.d.NativeCreateTag(ctx)
			require.NoError(t, err)
			f.disk.Tags = map[string]*string{OnlineCreateTag: &tag}
			f.disk.Properties.CreationData = &armcompute.CreationData{CreateOption: ptr.To(armcompute.DiskCreateOptionEmpty)}
			switch bad {
			case "missing-tag":
				delete(f.disk.Tags, OnlineCreateTag)
			case "changed-tag":
				f.disk.Tags[OnlineCreateTag] = ptr.To("another-operation")
			case "clone":
				f.disk.Properties.CreationData.CreateOption = ptr.To(armcompute.DiskCreateOptionCopy)
			case "missing-guid":
				f.disk.Properties.UniqueID = nil
			case "wrong-size":
				f.disk.Properties.DiskSizeBytes = ptr.To[int64](2 * gib)
			case "updating":
				f.disk.Properties.ProvisioningState = ptr.To("Updating")
			}
			err = f.d.ConfirmFreshCreate(ctx, f.disk)
			require.Equal(t, codes.Unavailable, status.Code(err))
			err = f.d.EndNative(ctx, true, resourceID, []byte("response"))
			require.Equal(t, codes.Unavailable, status.Code(err), "normal CSI success alone cannot establish provenance")
			f.restart(t)
			_, r, err := f.d.read(t.Context())
			require.NoError(t, err)
			require.NotNil(t, r.Busy)
			require.Nil(t, r.Fresh)
			require.Empty(t, r.CreatedID)
		})
	}
}

func TestOnlineCreationLostFinalCommitReplaysWithoutAdoption(t *testing.T) {
	f := newOnlineFixture(t)
	ctx, _, err := f.d.BeginNative(t.Context(), "CreateVolume", "create", "", f.req.CompositeVolumeId, f.j.Owner)
	require.NoError(t, err)
	require.NoError(t, f.d.RecordCreateTarget(ctx, resourceID))
	tag, err := f.d.NativeCreateTag(ctx)
	require.NoError(t, err)
	f.disk.Tags = map[string]*string{OnlineCreateTag: &tag}
	f.disk.Properties.CreationData = &armcompute.CreationData{CreateOption: ptr.To(armcompute.DiskCreateOptionEmpty)}
	require.NoError(t, f.d.ConfirmFreshCreate(ctx, f.disk))
	lost := true
	f.f.client.PrependReactor("update", "configmaps", func(a ktesting.Action) (bool, runtime.Object, error) {
		if !lost {
			return false, nil, nil
		}
		lost = false
		next := a.(ktesting.UpdateAction).GetObject().(*core.ConfigMap).DeepCopy()
		n, err := strconv.Atoi(next.ResourceVersion)
		require.NoError(t, err)
		next.ResourceVersion = strconv.Itoa(n + 1)
		require.NoError(t, f.f.client.Tracker().Update(a.GetResource(), next, next.Namespace))
		return true, nil, errUncertain
	})
	response, err := proto.Marshal(&csi.CreateVolumeResponse{Volume: &csi.Volume{VolumeId: resourceID, CapacityBytes: gib}})
	require.NoError(t, err)
	require.Equal(t, codes.Unavailable, status.Code(f.d.EndNative(ctx, true, resourceID, response)))
	f.restart(t)
	got, err := f.d.CreateReplay(t.Context(), "create")
	require.NoError(t, err)
	require.Equal(t, response, got)
	_, r, err := f.d.read(t.Context())
	require.NoError(t, err)
	require.Nil(t, r.Busy)
	require.Equal(t, "azure-guid", r.Fresh.DiskUniqueID)
	require.Equal(t, f.j.Owner, r.Fresh.Owner)
	f.bind(t)
	f.disk.Properties.UniqueID = ptr.To("replacement-incarnation")
	_, err = f.connect(t, ReservationController).Reserve(t.Context(), f.req)
	require.Equal(t, codes.FailedPrecondition, status.Code(err), "same ARM ID cannot adopt a replacement GUID")
}
