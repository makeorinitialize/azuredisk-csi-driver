/*
Copyright 2026 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package devicelease

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"maps"
	"strings"

	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/compute/armcompute/v7"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"
	core "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/validation"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	coreclient "k8s.io/client-go/kubernetes/typed/core/v1"
	pb "sigs.k8s.io/azuredisk-csi-driver/pkg/devicelease/api/v1"
)

const onlineDomainKey = "online-domain.v1"

const OnlineCreateTag = "dmstack-online-create"

// FreshOrigin is historical creation provenance, NOT permission to format.
// A consumer still needs independent validation of its exact open descriptor
// and a one-time format intent/expected filesystem identity before mkfs.
type FreshOrigin struct {
	DomainUID                                                                types.UID
	OperationID, RequestDigest, ResourceID, DiskUniqueID, CompositeID, Owner string
	Namespace                                                                string
	NamespaceUID, PVCUID, ClassUID, NodeUID                                  types.UID
	PVC                                                                      string
	DeviceGeneration                                                         uint64
	CapacityBytes                                                            int64
	CreateOption                                                             string
}

// BackingConfig mirrors backingpvc.Config, not CSI caller-supplied parameters.
type BackingConfig struct {
	Namespace          string    `json:"namespace"`
	NamespaceUID       types.UID `json:"namespaceUID"`
	NodeName           string    `json:"nodeName"`
	NodeUID            types.UID `json:"nodeUID"`
	OriginStorageClass string    `json:"originStorageClass"`
	CacheStorageClass  string    `json:"cacheStorageClass"`
	OriginBytes        int64     `json:"originBytes"`
	CacheBytes         int64     `json:"cacheBytes"`
	OriginDriver       string    `json:"originDriver,omitempty"`
	CacheDriver        string    `json:"cacheDriver,omitempty"`
}

func (c BackingConfig) EffectiveOriginDriver() string {
	if c.OriginDriver == "" {
		return "disk.csi.azure.com"
	}
	return c.OriginDriver
}

func (c BackingConfig) EffectiveCacheDriver() string {
	if c.CacheDriver == "" {
		return "localdisk.csi.acstor.io"
	}
	return c.CacheDriver
}

func (c BackingConfig) validDrivers() bool {
	origin, cache := c.EffectiveOriginDriver(), c.EffectiveCacheDriver()
	return len(origin) <= 63 && len(cache) <= 63 &&
		len(validation.IsDNS1123Subdomain(origin)) == 0 && len(validation.IsDNS1123Subdomain(cache)) == 0 &&
		origin != cache && origin != "localdisk.csi.acstor.io" && cache != "disk.csi.azure.com"
}

// Defaults are comparison semantics only: never rewrite pinned old journal JSON.
func (c BackingConfig) same(other BackingConfig) bool {
	c.OriginDriver, c.CacheDriver = c.EffectiveOriginDriver(), c.EffectiveCacheDriver()
	other.OriginDriver, other.CacheDriver = other.EffectiveOriginDriver(), other.EffectiveCacheDriver()
	return c == other
}

// OnlineIdentity describes a single, never-reused canary domain. Its journal
// must be bootstrapped before ANY controller/node traffic, not discovered on a
// cache miss. The deployment must exclude old replicas and out-of-band actors.
type OnlineIdentity struct {
	ProviderID      string        `json:"providerID"`
	PoolID          string        `json:"poolID"`
	CompositeCRDUID types.UID     `json:"compositeCRDUID"`
	Backing         BackingConfig `json:"backing"`
}

func (i OnlineIdentity) same(other OnlineIdentity) bool {
	return i.ProviderID == other.ProviderID && i.PoolID == other.PoolID &&
		i.CompositeCRDUID == other.CompositeCRDUID && i.Backing.same(other.Backing)
}

type nativeIntent struct {
	ID, Method, Digest, ResourceID, CompositeID, Owner string
	Backing                                            *backingJournal
	Fresh                                              *FreshOrigin
}

type onlineRecord struct {
	Version        int
	Identity       OnlineIdentity
	Busy           *nativeIntent
	CreatedID      string
	CompositeID    string
	Owner          string
	CreateDigest   string
	CreateResponse []byte
	Backing        *backingJournal
	Fresh          *FreshOrigin
	Selection      *BlockSelection
	ReserveID      string
	ReserveInput   string
	Closed         bool
	ReleaseID      string
	ReleaseInput   string
}

type OnlineDomain struct {
	identity OnlineIdentity
	maps     coreclient.ConfigMapInterface
	name     string
	uid      types.UID
	kube     kubernetes.Interface
	dynamic  dynamic.Interface
}

func (i OnlineIdentity) valid() bool {
	b := i.Backing
	return validID(i.ProviderID) && validID(i.PoolID) && i.CompositeCRDUID != "" && b.validDrivers() &&
		b.Namespace != "" && b.Namespace != "default" && b.NamespaceUID != "" &&
		b.NodeName != "" && b.NodeUID != "" && b.OriginStorageClass != "" &&
		b.CacheStorageClass != "" && b.OriginStorageClass != b.CacheStorageClass &&
		b.OriginBytes > 0 && b.CacheBytes > 0 && b.OriginBytes%512 == 0 && b.CacheBytes%512 == 0
}

func InitialOnlineDomain(i OnlineIdentity) (map[string]string, error) {
	if !i.valid() {
		return nil, status.Error(codes.InvalidArgument, "incomplete isolated online domain")
	}
	data, err := json.Marshal(onlineRecord{Version: 1, Identity: i})
	return map[string]string{onlineDomainKey: string(data)}, err
}

func NewOnlineDomain(i OnlineIdentity, maps coreclient.ConfigMapInterface, name string, uid types.UID, kube kubernetes.Interface, dyn dynamic.Interface) (*OnlineDomain, error) {
	if !i.valid() || maps == nil || name == "" || uid == "" || kube == nil || dyn == nil {
		return nil, status.Error(codes.InvalidArgument, "pinned domain journal and direct Kubernetes clients required")
	}
	return &OnlineDomain{identity: i, maps: maps, name: name, uid: uid, kube: kube, dynamic: dyn}, nil
}

func (d *OnlineDomain) read(ctx context.Context) (*core.ConfigMap, onlineRecord, error) {
	cm, err := d.maps.Get(ctx, d.name, metav1.GetOptions{})
	var r onlineRecord
	if err != nil {
		return nil, r, unavailable(err)
	}
	bad := status.Error(codes.Unavailable, "online admission journal unavailable or incompatible")
	if cm == nil || cm.UID != d.uid || cm.ResourceVersion == "" || cm.DeletionTimestamp != nil ||
		len(cm.Data[onlineDomainKey]) > 768*1024 || json.Unmarshal([]byte(cm.Data[onlineDomainKey]), &r) != nil ||
		r.Version != 1 || !r.Identity.same(d.identity) {
		return nil, r, bad
	}
	data, _ := json.Marshal(r)
	if string(data) != cm.Data[onlineDomainKey] || (r.CreatedID == "") != (r.CreateResponse == nil) ||
		(r.CreatedID == "") != (r.Backing == nil) ||
		(r.CreatedID == "") != (r.Fresh == nil) ||
		(r.Selection == nil) != (cm.Data["selection.v1"] == "") ||
		r.Selection != nil && (r.CreatedID != r.Selection.ResourceID || r.CompositeID != r.Selection.CompositeID || r.ReserveID == "" || r.ReserveInput == "") {
		return nil, r, bad
	}
	if r.Selection != nil {
		spec, _ := json.Marshal(r.Selection)
		if !r.Selection.valid() || cm.Data["selection.v1"] != string(spec) {
			return nil, r, bad
		}
		if r.Fresh != nil && (r.Fresh.DomainUID != d.uid || r.Fresh.ResourceID != r.CreatedID ||
			r.Fresh.Owner != r.Owner || r.Fresh.CompositeID != r.CompositeID || r.Fresh.DiskUniqueID == "" ||
			r.Fresh.RequestDigest != r.CreateDigest || r.Fresh.OperationID == "" || r.Fresh.CreateOption != "Empty" ||
			r.Fresh.DeviceGeneration != 1 || r.Fresh.CapacityBytes != d.identity.Backing.OriginBytes ||
			r.Fresh.Namespace != r.Backing.Config.Namespace || r.Fresh.NamespaceUID != r.Backing.Config.NamespaceUID ||
			r.Fresh.PVC != r.Backing.Origin.Name || r.Fresh.PVCUID != r.Backing.Origin.UID ||
			r.Fresh.ClassUID != r.Backing.Origin.ClassUID || r.Fresh.NodeUID != r.Backing.Config.NodeUID ||
			r.Selection != nil && r.Fresh.DiskUniqueID != r.Selection.DiskUniqueID) {
			return nil, r, bad
		}
	}
	return cm, r, nil
}

func (d *OnlineDomain) save(ctx context.Context, cm *core.ConfigMap, r onlineRecord) (*core.ConfigMap, error) {
	data, err := json.Marshal(r)
	if err != nil {
		return nil, err
	}
	next := cm.DeepCopy()
	next.Data[onlineDomainKey] = string(data)
	saved, err := d.maps.Update(ctx, next, metav1.UpdateOptions{})
	if apierrors.IsConflict(err) {
		return nil, status.Error(codes.Aborted, "concurrent online admission")
	}
	if err != nil {
		return nil, unavailable(err)
	}
	if saved == nil || saved.UID != d.uid || saved.DeletionTimestamp != nil || saved.ResourceVersion == "" ||
		saved.ResourceVersion == cm.ResourceVersion || !maps.Equal(saved.Data, next.Data) {
		return nil, status.Error(codes.Unavailable, "online admission commit unconfirmed")
	}
	return saved, nil
}

func (d *OnlineDomain) Check(ctx context.Context) error {
	_, _, err := d.read(ctx)
	if err == nil {
		err = d.checkDomainObjects(ctx)
	}
	if err == nil {
		_, _, err = d.checkScope(ctx)
	}
	return err
}

type nativeContextKey struct{}
type nativeToken struct {
	domain *OnlineDomain
	id     string
}

// BeginNative serializes the whole opt-in driver domain, not only already
// enrolled disks. Failures/crashes retain Busy forever; no TTL releases it.
// The one-volume canary deliberately does not reconcile ambiguous ARM work.
func (d *OnlineDomain) BeginNative(ctx context.Context, method, digest, resourceID, compositeID, owner string) (context.Context, *BlockHold, error) {
	cm, r, err := d.read(ctx)
	if err != nil {
		return ctx, nil, err
	}
	if r.Busy != nil {
		return ctx, nil, status.Error(codes.Unavailable, "native operation outcome retained; no automatic recovery")
	}
	var source *backingJournal
	switch method {
	case "CreateVolume":
		if r.Closed || r.CreatedID != "" || compositeID == "" || owner == "" {
			return ctx, nil, status.Error(codes.FailedPrecondition, "one fresh backing creation per domain")
		}
		proof, proofErr := d.resolveBacking(ctx, compositeID, false)
		if proofErr != nil {
			return ctx, nil, proofErr
		}
		if proof.Journal.Owner != owner {
			return ctx, nil, backingIdentityError()
		}
		source = &proof.Journal
	case "ControllerPublishVolume", "NodeStageVolume", "NodePublishVolume":
		if r.Closed || r.Selection == nil || !strings.EqualFold(resourceID, r.CreatedID) {
			return ctx, nil, status.Error(codes.FailedPrecondition, "provider enrollment required before publication")
		}
		if cm.Data["phase"] != "published" && !(method == "ControllerPublishVolume" && cm.Data["phase"] == "selected") {
			return ctx, nil, status.Error(codes.FailedPrecondition, "live hold or uncertain setup prevents new native setup")
		}
		proof, proofErr := d.resolveBacking(ctx, r.CompositeID, true)
		if proofErr != nil {
			return ctx, nil, proofErr
		}
		if r.Backing == nil || !proof.Journal.same(*r.Backing) || !strings.EqualFold(proof.VMID, r.Selection.VMID) ||
			proof.Journal.Owner != r.Owner || proof.Journal.Origin.Handle != r.CreatedID ||
			string(proof.Journal.Origin.UID) != r.Selection.PVCUID || string(proof.Journal.Origin.PVUID) != r.Selection.PVUID {
			return ctx, nil, backingIdentityError()
		}
	case "DeleteVolume", "ControllerUnpublishVolume", "NodeUnstageVolume", "NodeUnpublishVolume":
		if r.CreatedID == "" || !strings.EqualFold(resourceID, r.CreatedID) || r.Selection != nil && !r.Closed {
			return ctx, nil, status.Error(codes.FailedPrecondition, "exact backing disk and irreversible allocation closure required")
		}
		// Also fence a late Reserve when deletion beats first enrollment.
		r.Closed = true
	default:
		return ctx, nil, status.Error(codes.Unimplemented, "operation unsupported in isolated online canary")
	}
	var nonce [16]byte
	if _, err := rand.Read(nonce[:]); err != nil {
		return ctx, nil, unavailable(err)
	}
	r.Busy = &nativeIntent{ID: hex.EncodeToString(nonce[:]), Method: method, Digest: digest, ResourceID: resourceID, CompositeID: compositeID, Owner: owner, Backing: source}
	if _, err = d.save(ctx, cm, r); err != nil {
		return ctx, nil, err
	}
	ctx = context.WithValue(ctx, nativeContextKey{}, nativeToken{d, r.Busy.ID})
	return ctx, d.hold(r), nil
}

func (d *OnlineDomain) EndNative(ctx context.Context, success bool, createdID string, response []byte) error {
	token, ok := ctx.Value(nativeContextKey{}).(nativeToken)
	if !ok || token.domain != d {
		return status.Error(codes.Unavailable, "missing native admission")
	}
	if !success {
		return nil // Never infer that an error means no physical effect.
	}
	cm, r, err := d.read(ctx)
	if err != nil {
		return err
	}
	if r.Busy == nil || r.Busy.ID != token.id {
		return status.Error(codes.Aborted, "native admission changed")
	}
	if r.Busy.Method == "CreateVolume" {
		if _, err := armKey(createdID); err != nil || createdID != r.Busy.ResourceID || len(response) == 0 || len(response) > 64*1024 || r.Busy.Fresh == nil {
			return status.Error(codes.Unavailable, "native creation result not journalable")
		}
		r.CreatedID, r.CreateResponse, r.CreateDigest = createdID, response, r.Busy.Digest
		r.CompositeID, r.Owner = r.Busy.CompositeID, r.Busy.Owner
		r.Backing = r.Busy.Backing
		r.Fresh = r.Busy.Fresh
	}
	r.Busy = nil
	_, err = d.save(ctx, cm, r)
	return err
}

// RecordCreateTarget pins the driver's fully resolved ARM target before its
// absence check or CreateManagedDisk call. An ambiguous acknowledgement cannot
// dispatch creation; only this still-current admitted invocation may proceed.
func (d *OnlineDomain) RecordCreateTarget(ctx context.Context, id string) error {
	if _, err := armKey(id); err != nil {
		return err
	}
	t, ok := ctx.Value(nativeContextKey{}).(nativeToken)
	if !ok || t.domain != d {
		return status.Error(codes.Unavailable, "native creation admission missing")
	}
	cm, r, err := d.read(ctx)
	if err != nil {
		return err
	}
	if r.Busy == nil || r.Busy.ID != t.id || r.Busy.Method != "CreateVolume" || r.Busy.ResourceID != "" {
		return status.Error(codes.Aborted, "creation target already dispatched or changed")
	}
	r.Busy.ResourceID = id
	_, err = d.save(ctx, cm, r)
	return err
}

func (d *OnlineDomain) NativeCreateTag(ctx context.Context) (string, error) {
	t, ok := ctx.Value(nativeContextKey{}).(nativeToken)
	if !ok || t.domain != d {
		return "", status.Error(codes.Unavailable, "native creation admission missing")
	}
	_, r, err := d.read(ctx)
	if err != nil {
		return "", err
	}
	if r.Busy == nil || r.Busy.ID != t.id || r.Busy.Method != "CreateVolume" || r.Busy.ResourceID == "" || r.Busy.Fresh != nil {
		return "", status.Error(codes.Aborted, "native creation already confirmed or changed")
	}
	return blockRequestDigest(string(d.uid) + "\x00" + r.Busy.ID + "\x00" + r.Busy.Digest), nil
}

// ConfirmFreshCreate requires read-after-create ARM evidence attributable to the
// exact dispatch already persisted by RecordCreateTarget. No time heuristic,
// blank-filesystem inference, untagged adoption, or retrying CreateOrUpdate.
func (d *OnlineDomain) ConfirmFreshCreate(ctx context.Context, disk *armcompute.Disk) error {
	tag, err := d.NativeCreateTag(ctx)
	if err != nil {
		return err
	}
	cm, r, err := d.read(ctx)
	if err != nil {
		return err
	}
	t := ctx.Value(nativeContextKey{}).(nativeToken)
	if r.Busy == nil || r.Busy.ID != t.id || r.Busy.Backing == nil || r.Busy.Fresh != nil {
		return status.Error(codes.Aborted, "creation admission changed")
	}
	if disk == nil || disk.ID == nil || *disk.ID != r.Busy.ResourceID || disk.Tags[OnlineCreateTag] == nil || *disk.Tags[OnlineCreateTag] != tag ||
		disk.Properties == nil || disk.Properties.UniqueID == nil || *disk.Properties.UniqueID == "" ||
		disk.Properties.CreationData == nil || disk.Properties.CreationData.CreateOption == nil || *disk.Properties.CreationData.CreateOption != armcompute.DiskCreateOptionEmpty ||
		disk.Properties.CreationData.SourceResourceID != nil || disk.Properties.CreationData.SourceURI != nil ||
		disk.Properties.ProvisioningState == nil || *disk.Properties.ProvisioningState != "Succeeded" || disk.Properties.PropertyUpdatesInProgress != nil ||
		disk.Properties.DiskState == nil || *disk.Properties.DiskState != armcompute.DiskStateUnattached || disk.ManagedBy != nil || len(disk.ManagedByExtended) != 0 ||
		disk.Properties.MaxShares == nil || *disk.Properties.MaxShares != 1 || len(disk.Properties.ShareInfo) != 0 ||
		disk.Properties.DiskSizeBytes == nil || *disk.Properties.DiskSizeBytes != d.identity.Backing.OriginBytes {
		return status.Error(codes.Unavailable, "exact tagged fresh Empty disk creation not confirmed")
	}
	b := r.Busy.Backing
	r.Busy.Fresh = &FreshOrigin{DomainUID: d.uid, OperationID: r.Busy.ID, RequestDigest: r.Busy.Digest,
		ResourceID: *disk.ID, DiskUniqueID: *disk.Properties.UniqueID, CompositeID: r.Busy.CompositeID, Owner: r.Busy.Owner,
		Namespace: b.Config.Namespace, NamespaceUID: b.Config.NamespaceUID, PVC: b.Origin.Name, PVCUID: b.Origin.UID, ClassUID: b.Origin.ClassUID, NodeUID: b.Config.NodeUID,
		DeviceGeneration: 1, CapacityBytes: d.identity.Backing.OriginBytes, CreateOption: "Empty"}
	_, err = d.save(ctx, cm, r)
	return err
}

func (d *OnlineDomain) FreshOrigin(ctx context.Context, binding Binding) (FreshOrigin, error) {
	_, r, err := d.read(ctx)
	if err != nil {
		return FreshOrigin{}, err
	}
	if r.Busy != nil || r.Closed || r.Selection == nil || r.Selection.Binding != binding || r.Fresh == nil {
		return FreshOrigin{}, status.Error(codes.FailedPrecondition, "current exact enrolled creation provenance required")
	}
	return *r.Fresh, nil
}

func (d *OnlineDomain) NativeAdmitted(ctx context.Context) bool {
	t, ok := ctx.Value(nativeContextKey{}).(nativeToken)
	return ok && t.domain == d
}

func (d *OnlineDomain) CreateReplay(ctx context.Context, digest string) ([]byte, error) {
	_, r, err := d.read(ctx)
	if err != nil {
		return nil, err
	}
	if r.Busy != nil {
		return nil, status.Error(codes.Unavailable, "native creation outcome retained")
	}
	if r.Closed {
		return nil, status.Error(codes.FailedPrecondition, "online domain permanently closed")
	}
	if r.CreatedID != "" && r.CreateDigest != digest {
		return nil, status.Error(codes.AlreadyExists, "one backing creation per domain")
	}
	return r.CreateResponse, nil
}

func (d *OnlineDomain) hold(r onlineRecord) *BlockHold {
	if r.Selection == nil {
		return nil
	}
	return &BlockHold{s: *r.Selection, maps: d.maps, name: d.name, uid: d.uid, online: d}
}

func (d *OnlineDomain) checkHold(ctx context.Context, cm *core.ConfigMap) error {
	var r onlineRecord
	if err := json.Unmarshal([]byte(cm.Data[onlineDomainKey]), &r); err != nil || r.Version != 1 || !r.Identity.same(d.identity) {
		return status.Error(codes.Unavailable, "online hold domain unavailable")
	}
	data, _ := json.Marshal(r)
	if string(data) != cm.Data[onlineDomainKey] {
		return status.Error(codes.Unavailable, "incompatible online hold journal")
	}
	t, native := ctx.Value(nativeContextKey{}).(nativeToken)
	if native && t.domain == d {
		if r.Busy == nil || r.Busy.ID != t.id {
			return status.Error(codes.Aborted, "native admission no longer current")
		}
		return nil
	}
	if r.Busy != nil {
		return status.Error(codes.Unavailable, "native operation in flight or uncertain")
	}
	if r.Closed {
		return status.Error(codes.FailedPrecondition, "allocation permanently closed")
	}
	return nil
}

// ForceRetryAllowed is consulted by the actual batched detach helper.
func (d *OnlineDomain) ForceRetryAllowed(ctx context.Context, id string) (bool, error) {
	if !d.NativeAdmitted(ctx) {
		return false, status.Error(codes.Unavailable, "native detach admission required")
	}
	_, r, err := d.read(ctx)
	if err != nil {
		return false, err
	}
	t := ctx.Value(nativeContextKey{}).(nativeToken)
	if r.Busy == nil || r.Busy.ID != t.id {
		return false, status.Error(codes.Aborted, "native detach admission changed")
	}
	return r.Selection == nil || !strings.EqualFold(id, r.Selection.ResourceID), nil
}

// DeletionIdentity permits a read-only preflight before native admission, and
// the same check inside the admitted SDK helper. It never grants deletion of a
// replacement at the old ARM name, or treats registration absence as authority.
func (d *OnlineDomain) DeletionIdentity(ctx context.Context, id string) (FreshOrigin, error) {
	_, r, err := d.read(ctx)
	if err != nil {
		return FreshOrigin{}, err
	}
	t, native := ctx.Value(nativeContextKey{}).(nativeToken)
	if r.Busy != nil && (!native || t.domain != d || r.Busy.ID != t.id || r.Busy.Method != "DeleteVolume") {
		return FreshOrigin{}, status.Error(codes.Unavailable, "native deletion admission retained")
	}
	if r.Fresh == nil || !strings.EqualFold(id, r.CreatedID) || r.Selection != nil && !r.Closed {
		return FreshOrigin{}, status.Error(codes.FailedPrecondition, "exact backing incarnation and allocation closure required")
	}
	return *r.Fresh, nil
}

func (d *OnlineDomain) VerifyDeleteDisk(ctx context.Context, disk *armcompute.Disk) error {
	if disk == nil || disk.ID == nil {
		return status.Error(codes.Unavailable, "disk deletion target unavailable")
	}
	fresh, err := d.DeletionIdentity(ctx, *disk.ID)
	if err != nil {
		return err
	}
	if *disk.ID != fresh.ResourceID || disk.Properties == nil || disk.Properties.UniqueID == nil || *disk.Properties.UniqueID != fresh.DiskUniqueID ||
		disk.ManagedBy != nil || len(disk.ManagedByExtended) != 0 || len(disk.Properties.ShareInfo) != 0 {
		return status.Error(codes.FailedPrecondition, "exact unowned disk incarnation required before deletion")
	}
	return nil
}

func requestDigest(in proto.Message) (string, error) {
	data, err := (proto.MarshalOptions{Deterministic: true}).Marshal(in)
	return blockRequestDigest(string(data)), err
}

func (d *OnlineDomain) reserve(ctx context.Context, in *pb.ReserveRequest, observe BlockObserver) (*pb.Lease, error) {
	if in == nil || !validID(in.RequestId) || len(in.RequestId) > maxBlockRequestBytes ||
		in.Pool == nil || len(in.ProtoReflect().GetUnknown()) != 0 || len(in.Pool.ProtoReflect().GetUnknown()) != 0 ||
		in.Pool.Provider != d.identity.ProviderID || in.Pool.PoolId != d.identity.PoolID || in.CapacityBytes != uint64(d.identity.Backing.OriginBytes) {
		return nil, status.Error(codes.InvalidArgument, "exact configured pool and backing capacity required")
	}
	cm, r, err := d.read(ctx)
	if err != nil {
		return nil, err
	}
	digest, err := requestDigest(in)
	if err != nil {
		return nil, err
	}
	if r.ReserveID != "" && (r.ReserveID != in.RequestId || r.ReserveInput != digest) {
		return nil, status.Error(codes.AlreadyExists, "domain reservation input already bound")
	}
	if r.Busy != nil {
		return nil, status.Error(codes.Unavailable, "native operation must finish before registration")
	}
	if r.Closed {
		return nil, status.Error(codes.FailedPrecondition, "domain permanently closed")
	}
	if r.Selection != nil {
		return d.reservedLease(r), nil
	}
	proof, err := d.resolveBacking(ctx, in.CompositeVolumeId, true)
	if err != nil {
		return nil, err
	}
	if proof.RequestID != in.RequestId || r.CreatedID != proof.Journal.Origin.Handle || r.CompositeID != in.CompositeVolumeId || r.Owner != proof.Journal.Owner ||
		r.Backing == nil || r.Backing.Origin.Name != proof.Journal.Origin.Name || r.Backing.Origin.UID != proof.Journal.Origin.UID ||
		r.Backing.Origin.ClassUID != proof.Journal.Origin.ClassUID || r.Backing.Origin.Binding != proof.Journal.Origin.Binding ||
		r.Backing.Cache.Name != proof.Journal.Cache.Name || r.Backing.Cache.ClassUID != proof.Journal.Cache.ClassUID || r.Backing.Cache.Binding != proof.Journal.Cache.Binding {
		return nil, status.Error(codes.FailedPrecondition, "backing was not created under this domain admission")
	}
	s := BlockSelection{Provider: d.identity.ProviderID, PoolID: d.identity.PoolID,
		Binding: Binding{AllocationID: "online-" + blockRequestDigest(string(d.uid)+"\x00"+proof.Journal.Owner), CompositeID: in.CompositeVolumeId,
			ResourceID: proof.Journal.Origin.Handle, DeviceGeneration: 1, CapacityBytes: d.identity.Backing.OriginBytes},
		Owner: Owner{NodeID: d.identity.Backing.NodeName, Epoch: 1}, PV: proof.Journal.Origin.PVName, PVUID: string(proof.Journal.Origin.PVUID),
		Namespace: d.identity.Backing.Namespace, PVC: proof.Journal.Origin.Name, PVCUID: string(proof.Journal.Origin.UID)}
	disk, vm, err := observe(ctx, s)
	if err != nil {
		return nil, err
	}
	if disk == nil || disk.ID == nil || *disk.ID != s.ResourceID || disk.Properties == nil || disk.Properties.UniqueID == nil ||
		r.Fresh == nil || *disk.Properties.UniqueID != r.Fresh.DiskUniqueID ||
		disk.Tags[OnlineCreateTag] == nil || *disk.Tags[OnlineCreateTag] != blockRequestDigest(string(d.uid)+"\x00"+r.Fresh.OperationID+"\x00"+r.Fresh.RequestDigest) ||
		disk.Properties.CreationData == nil || disk.Properties.CreationData.CreateOption == nil || *disk.Properties.CreationData.CreateOption != armcompute.DiskCreateOptionEmpty ||
		disk.Properties.DiskSizeBytes == nil || *disk.Properties.DiskSizeBytes != s.CapacityBytes ||
		disk.Properties.MaxShares == nil || *disk.Properties.MaxShares != 1 || disk.ManagedBy != nil || len(disk.ManagedByExtended) != 0 ||
		len(disk.Properties.ShareInfo) != 0 || disk.Properties.ProvisioningState == nil || *disk.Properties.ProvisioningState != "Succeeded" ||
		disk.Properties.DiskState == nil || string(*disk.Properties.DiskState) != "Unattached" || disk.Properties.PropertyUpdatesInProgress != nil ||
		vm.ID == "" || !strings.EqualFold(proof.VMID, vm.ID) || vm.InstanceGUID == "" || vm.ProvisioningState != "Succeeded" {
		return nil, status.Error(codes.FailedPrecondition, "fresh exclusive unattached disk and target VM evidence required")
	}
	present, err := vm.hasDisk(s.ResourceID)
	if err != nil || present {
		return nil, status.Error(codes.FailedPrecondition, "disk already present on target VM")
	}
	s.DiskUniqueID, s.VMID, s.VMGUID = *disk.Properties.UniqueID, vm.ID, vm.InstanceGUID
	again, err := d.resolveBacking(ctx, in.CompositeVolumeId, true)
	if err != nil || again != proof {
		return nil, status.Error(codes.Aborted, "backing identity changed during registration")
	}
	initial, err := InitialBlockHold(s)
	if err != nil {
		return nil, err
	}
	next := cm.DeepCopy()
	for key, value := range initial {
		next.Data[key] = value
	}
	r.Selection, r.ReserveID, r.ReserveInput = &s, in.RequestId, digest
	r.Backing = &proof.Journal
	if _, err := d.save(ctx, next, r); err != nil {
		return nil, err
	}
	return d.reservedLease(r), nil
}

func (d *OnlineDomain) reservedLease(r onlineRecord) *pb.Lease {
	b := &publishedRPC{h: d.hold(r)}
	return &pb.Lease{Allocation: b.allocation(), PoolId: d.identity.PoolID,
		CapacityBytes: uint64(d.identity.Backing.OriginBytes), State: pb.LeaseState_LEASE_STATE_RESERVED}
}
